#include<stdio.h>

int main()
{
printf("ala ma kota\n");
return 0;
}
